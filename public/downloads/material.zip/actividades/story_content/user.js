function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5a6DD89Lw01":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

